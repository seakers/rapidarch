%% enum_random_standardform.m
function archs = enum_random_standardform(vec_num_options, Narch)
    Ndecisions = length(vec_num_options);
    archs = zeros(Narch,Ndecisions);
    for i = 1:Ndecisions
        archs(:,i) = randi(vec_num_options(i),[1 Narch]);
    end
end